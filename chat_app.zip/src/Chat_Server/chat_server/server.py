import json
import socket
import threading

import chat_server.util.mongo as mongo
import chat_server.util.user as user


class Server:
    users_dict = {}
    IP = "127.0.0.1"
    PORT = 1234
    max_connect_queue = 5

    def __init__(self):
        self.mongoDb = mongo.Mongo()
        self.server_socket = socket.socket()
        self.server_socket.bind((self.IP, self.PORT))
        self.server_socket.listen(self.max_connect_queue)
        print("server online")
        self.attempt_connection()

    def attempt_connection(self):
        print('Waiting for incoming connections...')
        try:
            while True:
                client_socket, client_address = self.server_socket.accept()
                print(f"Client connected: {client_address}")
                handle_thread = threading.Thread(target=self.handle_login, args=(client_socket, client_address,))
                print("handling client...")
                handle_thread.start()
        except Exception as e:
            print(f"Client instance creation error: {str(e)}")
            self.server_socket.close()
            exit(0)

    def handle_login(self, client_socket, client_address):
        connecting_user = None

        try:
            while connecting_user is None:
                # listen for client username
                user_input_json = json.loads(client_socket.recv(1024).decode())
                print(f"handle_login(): {user_input_json}")
                input_type = user_input_json['Code']
                username = user_input_json['Sender']

                if input_type == "login":
                    connecting_user = self.login(username, client_socket, client_address)
                    if connecting_user is not None:
                        # get friends list + send list to client
                        friends_list = self.mongoDb.get_friends_list(username)
                        json_string = self.json_builder("friends list", f"{friends_list}", "server", username)
                        client_socket.send(json_string)

                        # find online friends + send online list to client
                        online_friends_list = self.find_online_friends(friends_list)
                        json_string = self.json_builder(
                            "online friends", f"{online_friends_list}", "server", username)
                        client_socket.send(json_string)

                        # broadcast initiating_user online to all online friends
                        self.broadcast_online_status(username, online_friends_list)

                elif input_type == "register":
                    connecting_user = self.register(username, client_socket, client_address)

            self.handle_incoming_message(connecting_user)

        except ConnectionResetError:
            print(f"{client_address} has disconnected")

    def is_user_in_db(self, input_username):
        user_in_db = False
        db_usernames = self.mongoDb.get_all_users()
        if input_username in db_usernames:
            user_in_db = True

        return user_in_db

    def register(self, input_username, client_socket, client_address):
        connecting_user = None
        if self.is_user_in_db(input_username):
            json_string = self.json_builder(code="register error", sender="server", addressee=input_username)
            client_socket.send(json_string)

        else:
            connecting_user = user.User(input_username, client_socket, client_address)
            Server.users_dict[connecting_user.username] = connecting_user

            json_string = self.json_builder(code="register success", sender="server", addressee=input_username)
            client_socket.send(json_string)
            self.mongoDb.add_user(input_username)

        return connecting_user

    def login(self, input_username, client_socket, client_address):
        connecting_user = None
        if self.is_user_in_db(input_username):
            # if the initiating_user is in the db, create initiating_user object in memory, and send success to client, return the initiating_user object
            connecting_user = user.User(input_username, client_socket, client_address)
            Server.users_dict[connecting_user.username] = connecting_user
            json_string = self.json_builder(code="login success", sender="server", addressee=input_username)
            client_socket.send(json_string)

        else:
            json_string = self.json_builder(code="login error", sender="server", addressee=input_username)
            client_socket.send(json_string)

        return connecting_user

    @staticmethod
    def find_online_friends(friends_list):
        online_friends_list = []
        for friend in friends_list:
            try:
                if Server.users_dict[friend].online:
                    online_friends_list.append(friend)
            except KeyError:
                print(f"find_online_friends(): {friend} offline")

        return online_friends_list

    def broadcast_online_status(self, input_username, online_friends_list):
        for friend in online_friends_list:
            json_string = self.json_builder(code="friend online", sender=input_username, addressee=friend)
            Server.users_dict[friend].client_socket.send(json_string)

    def broadcast(self, content, passed_user):
        # only send to online users
        for user_obj in Server.users_dict.values():
            if user_obj.online and user_obj.client_socket != passed_user.client_socket:
                print(f"broadcast(): send message to {user_obj.username}")

                json_string = self.json_builder("broadcast", content, passed_user.username, user_obj.username)
                user_obj.client_socket.send(json_string)

            # When a initiating_user is offline add messages to some kind of queue system for when they return
            else:
                pass

    def handle_incoming_message(self, connecting_user):

        while True:
            json_string = connecting_user.client_socket.recv(1024).decode()
            received_json = json.loads(json_string)

            code_ = received_json["Code"]
            if code_ == "message":
                self.direct_message(received_json)
            elif code_ == "new friend":
                self.add_new_friend(received_json, connecting_user)
            elif code_ == "history":
                # Load conversation history
                conversation_history = self.mongoDb.load_conversation(received_json)

                connecting_user.client_socket.send(self.json_builder(
                    "history", str(conversation_history), received_json["Sender"], received_json["Addressee"]
                ))

    def direct_message(self, dm_object):
        print(f"direct_message(): {dm_object}")

        addressee_socket = Server.users_dict[dm_object["Addressee"]].client_socket

        self.mongoDb.update_conversation(dm_object["Sender"], dm_object["Addressee"], dm_object["Content"])

        json_string = self.json_builder(
            code="message", content=dm_object["Content"], sender=dm_object["Sender"], addressee=dm_object["Addressee"])
        addressee_socket.send(json_string)

    def add_new_friend(self, incoming_object, user_object):
        friend_name = incoming_object['Content']
        user_name = incoming_object["Sender"]
        print(f"new_friend_handle(): {friend_name}")
        # check if friend name is in chat_db
        if self.mongoDb.is_friend_in_db(friend_name):
            print("new_friend_handle(): friend found")

            # add friend to initiating_user's friends list AND add initiating_user to friend's friends list
            user_success = self.mongoDb.add_to_friends_list(user_name, friend_name)
            friend_success = self.mongoDb.add_to_friends_list(friend_name, user_name)

            # send success json string to client if both updates are successful
            # (TODO: remove boolean when implementing friend request caching)
            if user_success and friend_success:
                json_string = self.json_builder("new friend success", friend_name, "server", user_name)
                user_object.client_socket.send(json_string)
                self.mongoDb.create_conversation(user_name, friend_name)
            else:
                json_string = self.json_builder("new friend error: friend exists", friend_name, "server", user_name)
                user_object.client_socket.send(json_string)

            # check if the new friend is online, by trying to access property user_Dict[friends name].Online
            try:
                friend_object = Server.users_dict[friend_name]
                if friend_object.online:
                    # send 'new friend success' friends client_socket
                    json_string = self.json_builder("new friend success", user_name, "server", friend_name)
                    friend_object.client_socket.send(json_string)

                    # broadcast online status to both
                    self.broadcast_online_status(user_name, [friend_name])
                    self.broadcast_online_status(friend_name, [user_name])

            except KeyError:
                print("new_friend_handle(): Friend not online")

        else:
            # error code: 'friend not in chat_db'
            json_string = self.json_builder("new friend error: not found", friend_name, "server", user_name)
            user_object.client_socket.send(json_string)

    @staticmethod
    def json_builder(code, content=None, sender=None, addressee=None):
        json_object = {
            "Code": code,
            "Content": content,
            "Sender": sender,
            "Addressee": addressee
        }
        json_string = json.dumps(json_object, separators=(',', ':'))
        json_string = f"{json_string}\r\n".encode()
        return json_string


if __name__ == "__main__":
    Server()
