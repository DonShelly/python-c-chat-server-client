import datetime
import pprint

from pymongo import MongoClient


class Mongo:
    PORT = 27017
    IP = "127.0.0.1"
    client = None
    chat_db = None

    def __init__(self):
        self.client = MongoClient(host=self.IP, port=self.PORT)
        self.chat_db = self.client.chat_db

    def add_user(self, username):
        try:
            user_doc = {
                'username': username,
                'password': None,
                'friends_list': []
            }
            # insert user_doc into users table
            self.chat_db.users.insert_one(user_doc)

        except Exception as e:
            print(f"Exception thrown adding {username} to db: {str(e)}")

    """
    Update password for a single initiating_user

    :Parameters:
        - 'username' The username of the target initiating_user.
        - 'md5_password' The MD5 encryption value of the users password.
    
    :Returns:
        None
        
    .. version added:: dev
    """
    def update_user_pass(self, username, md5_password):
        try:
            filter_doc = {
                "username": username
            }

            update_doc = {
                "$set": {
                    "password": md5_password
                }
            }

            result = self.chat_db.users.update_one(filter_doc, update_doc, True)
            modified_count = result.modified_count

            if modified_count > 0:
                print(f"Updated {modified_count} password for {username}")
            else:
                print(f"Failed to update password for {username}")
        except Exception as e:
            print(f"Exception thrown changing password for {username}: {str(e)}")

    def get_all_users(self):
        usernames = []
        print("DEBUG: fetching users")
        cursor = self.chat_db.users.find({})
        for document in cursor:
            usernames.append(document['username'])
        return usernames

    def is_friend_in_db(self, friend_name):
        friend_in_db = False
        friend = self.chat_db.users.find_one({"username": friend_name})
        if friend:
            print(f"mongo.if_user_in_db(): found in DB - {friend['username']}")
            friend_in_db = True
        return friend_in_db

    def add_to_friends_list(self, user_name, friend_name):
        friend_added_success = False
        print(f"mongo.new_friend_link(): {user_name} {friend_name}")

        # check if the users friends list already has friend name
        results_cursor = self.chat_db.users.find({"username": user_name, "friends_list": friend_name})
        results_list = list(results_cursor)
        print(results_list)

        # if 0 results, update DB friend list and return True
        if len(results_list) == 0:
            print(f"mongo.new_friend_link(): Can add {friend_name} to {user_name} list")
            self.chat_db.users.update({"username": user_name}, {"$addToSet": {"friends_list": friend_name}})
            print(
                f"mongo.add_to_friends_list(): updated {user_name} list {list(self.chat_db.users.find({'username': user_name}))}")
            friend_added_success = True

        # else if friend already in list, return False
        else:
            print(f"mongo.new_friend_link(): {friend_name} already in {user_name} list")

        return friend_added_success

    def get_friends_list(self, user_name):
        # query db for doc with username, and return array of friends
        results_cursor = self.chat_db.users.find({"username": user_name})
        user_dict = results_cursor[0]
        return user_dict["friends_list"]

    def create_conversation(self, initiating_user, friend):
        print(f"mongo.create_conversation(): {initiating_user} {friend}")
        new_conversation = {
            "users": [initiating_user, friend],
            "history": []
        }
        result = self.chat_db.conversations.insert_one(new_conversation)

        cursor = self.chat_db.conversations.find(
            {"users":
                 {'$all':
                      [friend, initiating_user]
                  }
             })
        print(f"mongo.create_conversation(): created conversation {cursor[0]}")
        print(f"mongo.create_conversation(): id {cursor[0]['_id']}")

    def load_conversation(self, json):
        conversation_history = []
        query = {
            "users":
                {'$all':
                    [json["Sender"], json["Addressee"]]
                 }
        }

        cursor = self.chat_db.conversations.find(query, {"history": True}, 0, 1)

        for item in cursor:
            for message in item["history"]:
                conversation_history.append(message)
            
        pprint.pprint(conversation_history)
        return conversation_history

    def update_conversation(self, sender_username, addressee_username, message):
        query = {
            "users":
                {'$all':
                    [sender_username, addressee_username]
                 }
        }

        update = {
            '$addToSet': {
                'history': [sender_username, message, str(datetime.datetime.utcnow())]
            }
        }
        self.chat_db.conversations.update(query, update)
