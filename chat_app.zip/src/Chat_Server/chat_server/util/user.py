import socket
from dataclasses import dataclass


@dataclass
class User:
    username: str
    client_socket: socket.socket()
    client_address: tuple
    online: bool = True
