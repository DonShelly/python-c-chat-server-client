﻿
namespace ChatInterface
{
    partial class Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PostMessageButton = new System.Windows.Forms.Button();
            this.textBoxMessage = new System.Windows.Forms.TextBox();
            this.listViewChatDisplay = new System.Windows.Forms.ListView();
            this.labelUsername = new System.Windows.Forms.Label();
            this.LogInButton = new System.Windows.Forms.Button();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textboxPassword = new System.Windows.Forms.TextBox();
            this.textboxUsername = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NewUserUsername = new System.Windows.Forms.TextBox();
            this.NewUserPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.NewUserButton = new System.Windows.Forms.Button();
            this.NewFriendName = new System.Windows.Forms.TextBox();
            this.AddNewFriendButton = new System.Windows.Forms.Button();
            this.listViewFriends = new System.Windows.Forms.ListView();
            this.nameCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.onlineCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Chat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // PostMessageButton
            // 
            this.PostMessageButton.Location = new System.Drawing.Point(477, 309);
            this.PostMessageButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PostMessageButton.Name = "PostMessageButton";
            this.PostMessageButton.Size = new System.Drawing.Size(86, 46);
            this.PostMessageButton.TabIndex = 17;
            this.PostMessageButton.Text = "POST";
            this.PostMessageButton.UseVisualStyleBackColor = true;
            this.PostMessageButton.Click += new System.EventHandler(this.PostMessageButton_Click);
            // 
            // textBoxMessage
            // 
            this.textBoxMessage.Location = new System.Drawing.Point(188, 309);
            this.textBoxMessage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxMessage.Multiline = true;
            this.textBoxMessage.Name = "textBoxMessage";
            this.textBoxMessage.Size = new System.Drawing.Size(286, 47);
            this.textBoxMessage.TabIndex = 16;
            // 
            // listViewChatDisplay
            // 
            this.listViewChatDisplay.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Chat});
            this.listViewChatDisplay.HideSelection = false;
            this.listViewChatDisplay.Location = new System.Drawing.Point(188, 123);
            this.listViewChatDisplay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listViewChatDisplay.Name = "listViewChatDisplay";
            this.listViewChatDisplay.Size = new System.Drawing.Size(376, 174);
            this.listViewChatDisplay.TabIndex = 15;
            this.listViewChatDisplay.UseCompatibleStateImageBehavior = false;
            this.listViewChatDisplay.View = System.Windows.Forms.View.Details;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Location = new System.Drawing.Point(33, 28);
            this.labelUsername.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(55, 13);
            this.labelUsername.TabIndex = 14;
            this.labelUsername.Text = "Username";
            // 
            // LogInButton
            // 
            this.LogInButton.Location = new System.Drawing.Point(102, 72);
            this.LogInButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(56, 28);
            this.LogInButton.TabIndex = 13;
            this.LogInButton.Text = "Log in";
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(36, 50);
            this.labelPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(53, 13);
            this.labelPassword.TabIndex = 12;
            this.labelPassword.Text = "Password";
            // 
            // textboxPassword
            // 
            this.textboxPassword.Location = new System.Drawing.Point(92, 49);
            this.textboxPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textboxPassword.Name = "textboxPassword";
            this.textboxPassword.Size = new System.Drawing.Size(76, 20);
            this.textboxPassword.TabIndex = 11;
            // 
            // textboxUsername
            // 
            this.textboxUsername.Location = new System.Drawing.Point(92, 26);
            this.textboxUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textboxUsername.Name = "textboxUsername";
            this.textboxUsername.Size = new System.Drawing.Size(76, 20);
            this.textboxUsername.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Existing Users";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(434, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "New Users";
            // 
            // NewUserUsername
            // 
            this.NewUserUsername.Location = new System.Drawing.Point(428, 24);
            this.NewUserUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewUserUsername.Name = "NewUserUsername";
            this.NewUserUsername.Size = new System.Drawing.Size(83, 20);
            this.NewUserUsername.TabIndex = 21;
            // 
            // NewUserPassword
            // 
            this.NewUserPassword.Location = new System.Drawing.Point(428, 49);
            this.NewUserPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewUserPassword.Name = "NewUserPassword";
            this.NewUserPassword.Size = new System.Drawing.Size(83, 20);
            this.NewUserPassword.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(368, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Username";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Password";
            // 
            // NewUserButton
            // 
            this.NewUserButton.Location = new System.Drawing.Point(428, 72);
            this.NewUserButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewUserButton.Name = "NewUserButton";
            this.NewUserButton.Size = new System.Drawing.Size(82, 28);
            this.NewUserButton.TabIndex = 25;
            this.NewUserButton.Text = "Create User";
            this.NewUserButton.UseVisualStyleBackColor = true;
            this.NewUserButton.Click += new System.EventHandler(this.NewUserButton_Click);
            // 
            // NewFriendName
            // 
            this.NewFriendName.Location = new System.Drawing.Point(35, 309);
            this.NewFriendName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NewFriendName.Name = "NewFriendName";
            this.NewFriendName.Size = new System.Drawing.Size(97, 20);
            this.NewFriendName.TabIndex = 26;
            // 
            // AddNewFriendButton
            // 
            this.AddNewFriendButton.Location = new System.Drawing.Point(35, 332);
            this.AddNewFriendButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AddNewFriendButton.Name = "AddNewFriendButton";
            this.AddNewFriendButton.Size = new System.Drawing.Size(96, 19);
            this.AddNewFriendButton.TabIndex = 27;
            this.AddNewFriendButton.Text = "Add Friend";
            this.AddNewFriendButton.UseVisualStyleBackColor = true;
            this.AddNewFriendButton.Click += new System.EventHandler(this.AddNewFriendButton_Click);
            // 
            // listViewFriends
            // 
            this.listViewFriends.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nameCol,
            this.onlineCol});
            this.listViewFriends.HideSelection = false;
            this.listViewFriends.Location = new System.Drawing.Point(9, 124);
            this.listViewFriends.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listViewFriends.Name = "listViewFriends";
            this.listViewFriends.Size = new System.Drawing.Size(150, 173);
            this.listViewFriends.TabIndex = 28;
            this.listViewFriends.UseCompatibleStateImageBehavior = false;
            this.listViewFriends.View = System.Windows.Forms.View.Details;
            this.listViewFriends.Click += new System.EventHandler(this.FriendsList_click);
            // 
            // nameCol
            // 
            this.nameCol.Text = "Friend";
            // 
            // onlineCol
            // 
            this.onlineCol.Text = "Online";
            // 
            // Chat
            // 
            this.Chat.Text = "";
            this.Chat.Width = 376;
            // 
            // Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 392);
            this.Controls.Add(this.listViewFriends);
            this.Controls.Add(this.AddNewFriendButton);
            this.Controls.Add(this.NewFriendName);
            this.Controls.Add(this.NewUserButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NewUserPassword);
            this.Controls.Add(this.NewUserUsername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PostMessageButton);
            this.Controls.Add(this.textBoxMessage);
            this.Controls.Add(this.listViewChatDisplay);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.LogInButton);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.textboxPassword);
            this.Controls.Add(this.textboxUsername);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Interface";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PostMessageButton;
        private System.Windows.Forms.TextBox textBoxMessage;
        private System.Windows.Forms.ListView listViewChatDisplay;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textboxPassword;
        private System.Windows.Forms.TextBox textboxUsername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NewUserUsername;
        private System.Windows.Forms.TextBox NewUserPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button NewUserButton;
        private System.Windows.Forms.TextBox NewFriendName;
        private System.Windows.Forms.Button AddNewFriendButton;
        private System.Windows.Forms.ListView listViewFriends;
        private System.Windows.Forms.ColumnHeader nameCol;
        private System.Windows.Forms.ColumnHeader onlineCol;
        private System.Windows.Forms.ColumnHeader Chat;
    }
}

