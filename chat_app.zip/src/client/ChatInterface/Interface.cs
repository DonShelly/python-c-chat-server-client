﻿using System;
using System.IO;
using System.Threading;
using System.Net.Sockets;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace ChatInterface
{
    public partial class Interface : Form
    {
        private static int PortNo = 1234;
        private static string ServerIp = "127.0.0.1";
        private static StreamWriter Writer;
        private static StreamReader Reader;
        private static string Username = string.Empty;
        private static string CurrentAddressee = string.Empty;

        /// CONSRUCTOR/INITIALISATION
        public Interface()
        {
            try
            {
                TcpClient socketClient = new TcpClient(ServerIp, PortNo);
                NetworkStream stream = socketClient.GetStream();
                Writer = new StreamWriter(stream);
                Reader = new StreamReader(stream);

                InitializeComponent();
                RequestUsername();
            }
            catch
            {
                Console.WriteLine("No server online");
                Environment.Exit(-1);
            }
        }

        /// GETS NEW USER CREATION DETAILS
        private void NewUserButton_Click(object sender, EventArgs e)
        {
            string code = "register";
            AttemptLogin(code, NewUserUsername.Text, NewUserPassword.Text);
        }

        /// GETS EXISTING USER LOGIN DETAILS
        private void LogInButton_Click(object sender, EventArgs e)
        {
            string code = "login";
            AttemptLogin(code, textboxUsername.Text, textboxPassword.Text);
        }

        /// IF DETAILS ARE COMPLETE, CONTRUCT JSONSTRING AND SEND LOG IN REQUSET TO SERVER + LISTEN FOR RESPONSE
        private void AttemptLogin(string code, string tempUsername, string tempPassword)
        {
            if (String.IsNullOrEmpty(tempUsername) || String.IsNullOrEmpty(tempPassword))
            {
                ClearDisplay();
                listViewChatDisplay.Items.Add("-- ERROR - LOGIN DETAILS ARE BLANK --");
            }
            else
            {
                HandleOutgoingMessage(code, tempPassword, tempUsername);
                string incomingJsonString = Reader.ReadLine();
                HandleIncomingObject(incomingJsonString);
            }
        }

        private void HandleOutgoingMessage(string code = "", string content = "", string sender = "", string addressee = "")
        {
            JsonObject jsonObject = new JsonObject
            {
                Code = code,
                Content = content,
                Sender = sender,
                Addressee = addressee
            };
            string jsonString = JsonConvert.SerializeObject(jsonObject);
            Console.WriteLine($"HandleOutgoingObject(): {jsonString}");
            Writer.WriteLine(jsonString);
            Writer.Flush();
        }

        private delegate void HandleIncomingObjectDelegate(string incomingJsonString);

        private void HandleIncomingObject(string incomingJsonString)
        {
            Console.WriteLine($"HandleIncomingObject: {incomingJsonString}");            

            bool loginSuccess = false;
            JsonObject jsonObject = JsonConvert.DeserializeObject<JsonObject>(incomingJsonString);

            switch (jsonObject.Code)
            {
                case "register success":
                    listViewChatDisplay.Items.Add("-- USER CREATION SUCCESSFUL! --");
                    loginSuccess = true;
                    break;
                case "register error":
                    listViewChatDisplay.Items.Add("-- ERROR: USERNAME ALREADY EXISTS --");
                    break;
                case "login success":
                    listViewChatDisplay.Items.Add("-- LOGIN SUCCESSFUL! --");
                    loginSuccess = true;
                    break;
                case "login error":
                    listViewChatDisplay.Items.Add("-- ERROR - INVALID USER DETAILS --");
                    break;
                case "message":
                    listViewChatDisplay.Items.Add($"{jsonObject.Sender}: {jsonObject.Content}");
                    break;
                case "broadcast":
                    listViewChatDisplay.Items.Add($"{jsonObject.Sender}: {jsonObject.Content}");
                    break;
                case "new friend success":
                    // add friend username to gui friends list + add to friends array in client memory
                    listViewFriends.Items.Add(jsonObject.Content);
                    NewFriendName.Clear();
                    listViewChatDisplay.Items.Add("-- NEW FRIEND ADDED --");
                    break;
                case "new friend error: not found":
                    // throw error - no user by that name found
                    listViewChatDisplay.Items.Add("-- ERROR: NO NEW FRIEND USERNAME FOUND --");
                    break;
                case "new friend error: friend exists":
                    listViewChatDisplay.Items.Add("-- ERROR: FRIEND ALREADY EXISTS --");
                    break;
                case "friends list":
                    /// Content is array of names
                    DisplayFriendsList(jsonObject.Content);
                    break;
                case "online friends":
                    DisplayFriendsOnline(jsonObject.Content);
                    break;
                case "friend online":
                    UpdateFriendOnlineStatus(jsonObject.Sender); 
                    break;
                case "history":
                    string history2dArray = jsonObject.Content;
                    string[][] conversationHistory = JsonConvert.DeserializeObject<string[][]>(history2dArray);

                    foreach (string[] message in conversationHistory)
                        listViewChatDisplay.Items.Add($"{message[0]}: {message[1]} - {message[2]}");
                    
                    break;
                default:
                    Console.WriteLine("-- ERROR: INCOMING MESSAGE NOT RECOGNISED --");
                    break;
            }

            if (loginSuccess)
            {
                Username = jsonObject.Addressee;
                LogInButton.Enabled = false;
                Thread thread = new Thread(ReceiveMessage);
                thread.IsBackground = true;
                thread.Start();
            }
        }

        private void SendMessage(string message)
        {
            Writer.WriteLine(message);
            Writer.Flush();
        }

        /// GETS USER'S NEW TYPED MESSAGE, SENDS IT TO SERVER
        private void PostMessageButton_Click(object sender, EventArgs e)
        {
            if(LoggedIn())
            {
                string message = textBoxMessage.Text;
                string code = "message";
                /// If no addressee, then send as broadcast message
                if (String.IsNullOrEmpty(CurrentAddressee))
                {
                    code = "broadcast";
                }          
                HandleOutgoingMessage(code, message, Username, CurrentAddressee);
                
                listViewChatDisplay.Items.Add($"{Username}: {message}");
                textBoxMessage.Clear();
            }
            else 
            {
                ClearDisplay();
                listViewChatDisplay.Items.Add("-- ERROR - LOG IN REQUIRED TO POST MESSAGES --");
            }
        }

        /// TO SHOW RECV MESSAGES ON THE MAIN THREAD GUI FORM, NEED TO USE 'DELEGATE' FUNCTION, AND PASS 'DISPLAYMESSAGES' FUNCTION AS ARG
        private void ReceiveMessage()
        {
            Console.WriteLine("-- THREAD STARTED, LISTENING FOR BORADCAST --");
            try
            {
                while (true)
                {
                    string incomingJsonString = Reader.ReadLine();
                    Invoke(new HandleIncomingObjectDelegate(HandleIncomingObject), incomingJsonString);
                }
            }
            catch (Exception e) 
            { 
                Console.WriteLine($"Exception receiving message: {e}"); 
            }
        }

        // TODO: USER FUNCTIONS TO BE USED IN FUTURE VERISON

        // Create new friend
        private void AddNewFriendButton_Click(object sender, EventArgs e)
        {
            if(LoggedIn())
            {
                string code = "new friend";
                string newFriendName = NewFriendName.Text;
                HandleOutgoingMessage(code, content: newFriendName, sender: Username, addressee: "server");

                // SERVERACTION: server checks if friend username exists in db
                    // if exists
                        // add friend connection in db
                        // respond with SUCCESS
                    // if NOT exist
                        // respond with FALIURE
            }

            // handle server reponse => SEE HANDLE INCOMING OBJECT METHOD
               
            else
            {
                ClearDisplay();
                listViewChatDisplay.Items.Add("-- ERROR: MUST BE LOGGED IN TO CREATE FRIENDS --");
            }
        }

        private void DisplayFriendsList(string friendsArrayAsString) { 
            /// Deserialize jsonObject.Content string to an dictionary, then display each name and status to GUI
            Console.WriteLine(friendsArrayAsString);
            string[] friendsList = JsonConvert.DeserializeObject<string[]>(friendsArrayAsString);
            foreach (string friend in friendsList)
            {
                DisplayFriend(friend);
            }
        }

        private void DisplayFriend(string friendName)
        {
            ListViewItem friendObj = new ListViewItem(new[] {friendName, "-" });
            listViewFriends.Items.Add(friendObj);
        }

        private void DisplayFriendsOnline(string onlineFriendsArrayAsString)
        {
            string[] onlineFriends = JsonConvert.DeserializeObject<string[]>(onlineFriendsArrayAsString);
            foreach(string friend in onlineFriends)
            {
                UpdateFriendOnlineStatus(friend);
            }
        }

        private void UpdateFriendOnlineStatus(string friendName) 
        {
            /// get index of friend and replace with updated friend object
            ListViewItem friendObj = listViewFriends.FindItemWithText(friendName);
            int index = friendObj.Index;

            ListViewItem updatedFriendObj = new ListViewItem(new[] { friendName, "ONLINE" });
            listViewFriends.Items.RemoveAt(index);
            listViewFriends.Items.Insert(index, updatedFriendObj);
        }

        private void FriendsList_click(object sender, EventArgs e)
        {
            CurrentAddressee = listViewFriends.SelectedItems[0].SubItems[0].Text;
            Console.WriteLine($"FriendsList_click(): {CurrentAddressee}");
            HandleOutgoingMessage("history", "", Username, CurrentAddressee);
            ClearDisplay();
        }

        // TODO: USER FUNCTIONS TO BE USED IN FUTURE VERISON
        private void DirectMessage() 
        { 
            // select friend from friends list
            // consrtuct json object with code for direct message + sedder + addressee
            // send object to server
            // SERVERACTION: send object onto 
        }
        


        private void RequestUsername() 
        { 
            listViewChatDisplay.Items.Add("-- ENTER USERNAME AND PASSWORD --"); 
        }

        private bool LoggedIn() 
        { 
            return Username != ""; 
        }

        private void ClearDisplay() 
        { 
            listViewChatDisplay.Items.Clear(); 
        }

    }

    public class JsonObject
    {
        public string Code { get; set; }
        public string Content { get; set; }
        public string Sender { get; set; }
        public string Addressee { get; set; }
    }

}
